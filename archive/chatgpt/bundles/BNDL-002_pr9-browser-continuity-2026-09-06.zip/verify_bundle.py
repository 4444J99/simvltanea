"""Verify delivered bytes and recorded evidence, not a new browser execution."""
from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parent

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    manifest=json.loads((ROOT/'SHA256SUMS.json').read_text())
    for name,expected in manifest.items():
        p=(ROOT/name).resolve()
        if not p.is_relative_to(ROOT) or not p.is_file() or sha(p)!=expected:
            raise SystemExit(f'Integrity failure: {name}')
    ledger=json.loads((ROOT/'BROWSER_CONTINUITY_EVIDENCE.json').read_text())
    ids=[]
    for name,record in ledger['final_logs'].items():
        p=ROOT/'evidence/logs'/name
        assert sha(p)==record['sha256'],name
        text=p.read_text()
        assert text.strip().endswith('OK'),name
        matched=re.findall(r'^test_\w+ \(([^)]+)\) \.\.\. ok$',text,re.M)
        assert len(matched)==record['passed'],name
        ids+=matched
    assert len(ids)==len(set(ids))==81
    for name,expected in ledger['raw_trace_sha256'].items():
        p=ROOT/'evidence/independent-continuity'/name
        assert sha(p)==expected,name
        record=json.loads(p.read_text())
        assert record['passed'] and record['transport']=='in-memory',name
    for name,expected in ledger['test_and_runtime_sha256'].items():
        assert sha(ROOT/'source/incubator/triptych-video-canon'/name)==expected,name
    for attempt in ledger['http_attempts']:
        text=(ROOT/'evidence/logs'/attempt['log']).read_text()
        assert 'ERR_BLOCKED_BY_ADMINISTRATOR' in text and 'FAILED (errors=1)' in text
    print(f'Verified {len(manifest)} file hashes; 81 recorded distinct passes, 16 traces, two separate HTTP errors.')

if __name__=='__main__':main()
