# PR #9 browser continuity execution bundle

Commit: `c3fbae7d4d354de0306e62f123c77eadddc4565e` in `organvm/portvs`.
This is a scoped reproduction snapshot, not a full repository clone.

Start with `BROWSER_CONTINUITY_RECEIPT.md` and its machine-readable evidence ledger.
The receipt separates 81 distinct passing tests in completed in-memory runs from
two failed HTTP attempts. Served HTTP/WebCrypto and physical-device orientation
remain unverified. The hosted Analyze (python) check failed; see remote-commit.json.

`source/incubator/triptych-video-canon/` contains verified source plus the tested
additions, synthetic media and state files. Tests rebuild portable previews.
Run from that directory with the prerequisites specified in the receipt and
requirements-runtime-proof.txt. Fonts are local prerequisites, never bundled.
Do not change browser policy or silently substitute in-memory IO for HTTP.

`evidence/independent-continuity/` contains 16 raw result/trace JSON files and
21 actual screenshots. The two contact sheets show these screenshots. Original
state/source/compiler hashes are preserved in traces and the evidence ledger.
`evidence/existing-browser/` holds the rerun existing native-browser traces.
`evidence/logs/` contains final logs, both HTTP failures and the honest failed
Git-status attempt (this was not a Git checkout). Development smoke logs are
separate and excluded from the 81-test total. No old shared transport marker is
used to relabel per-test evidence.

The upstream source manifest has 21 Git blob hashes. INCUBATION.md is intentionally
changed in the delivered source; its old version is preserved under
`evidence/upstream-original/`. The other changed/new files and exact hashes are
listed in `evidence/changed-files.json`. The patch applies to the starting head.

All included media are synthetic engineering fixtures. This is not recovered
artwork, artist approval, a deployment, or an overall review-ready declaration.

`SHA256SUMS.json` covers every other file in this bundle. To verify its files,
run `python3 verify_bundle.py` from the bundle root. This checks bytes and recorded
run consistency; it does not rerun the browser. Reproduction commands are in
the receipt. Future executions require their own fresh evidence directory/logs;
a prior trace is not evidence that a later failed invocation passed.
